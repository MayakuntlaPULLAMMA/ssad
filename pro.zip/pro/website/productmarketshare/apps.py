from django.apps import Appconfig

class productconfig(Appconfig):
    name='productmarketshare'